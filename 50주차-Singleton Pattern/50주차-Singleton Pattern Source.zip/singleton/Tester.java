package singleton;

import java.util.concurrent.Executors;

public class Tester {
	private static final int LIMIT = 5;
	public static void main(String args[]) throws InterruptedException{
		runNormalClass();						delayFnc();
		runEagerInitialization();				delayFnc();
		runStaticBlockInitalization();			delayFnc();
		runLazyInitialization();				delayFnc();
		runThreadSafeInitalization();			delayFnc();
		runThreadSafeInitalizationDCL();		delayFnc();
		runInitializationOnDemandHolderIdiom();	delayFnc();
		runEnumInitialization();
	}
	
	public static void runNormalClass() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				NormalClass normalClass = new NormalClass();
				normalClass.print();
			});
		}
		
	}
	
	public static void runEagerInitialization() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				EagerInitialization eagerInitialization = EagerInitialization.getInstance();
				eagerInitialization.print();
			});
		}
	}
	
	public static void runStaticBlockInitalization() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				StaticBlockInitalization staticBlockInitalization = StaticBlockInitalization.getInstance();
				staticBlockInitalization.print();
			});
		}
	}
	
	public static void runLazyInitialization() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				LazyInitialization lazyInitialization = LazyInitialization.getInstance();
				lazyInitialization.print();
			});
		}
	}
	
	public static void runThreadSafeInitalization() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				ThreadSafeInitalization threadSafeInitalization = ThreadSafeInitalization.getInstance();
				threadSafeInitalization.print();
			});
		}
	}
	
	public static void runThreadSafeInitalizationDCL() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				ThreadSafeInitalizationDCL threadSafeInitalizationDCL = ThreadSafeInitalizationDCL.getInstance();
				threadSafeInitalizationDCL.print();
			});
		}
	}
	
	public static void runInitializationOnDemandHolderIdiom() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				InitializationOnDemandHolderIdiom initializationOnDemandHolderIdiom = InitializationOnDemandHolderIdiom.getInstance();
				initializationOnDemandHolderIdiom.print();
			});
		}
	}
	
	public static void runEnumInitialization() {
		for(int i = 0; i < LIMIT; i++) {
			Executors.newSingleThreadExecutor().execute(()->{
				EnumInitialization enumInitialization = EnumInitialization.getInstance();
				enumInitialization.print();
			});
		}
	}
	
	public static void delayFnc() throws InterruptedException {
		Thread.sleep(500);
		System.out.println();
		System.out.println("--------------------------------------------------------------------------------------");
		System.out.println();
		Thread.sleep(500);
	}
}