package VO;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.*;
import com.sun.istack.internal.NotNull;
import lombok.*;
import lombok.experimental.Delegate;
import lombok.extern.java.Log;

/**
Lombok?

Lombok이란 Java의 라이브러리로 반복되는 메소드를 Annotation을 사용해서 자동으로 작성해주는 라이브러리다. 
보통 DTO나 Model, Entity의 경우 여러 속성이 존재하고 이들이 가지는 프로퍼티에 대해서 Getter나 Setter, 
생성자 등을 매번 작성해줘야 하는 경우가 많은데 이러한 부분을 자동으로 만들어주는 라이브러리라고 할 수 있다.

또한 DTO와 같이 자주 변경되는 클래스의 경우 멤버 변수가 추가되거나 없어질 때마다 Getter, Setter, 생성자 등을 
수정해줘야 하는 경우가 발생한다. 이러한 경우에도 Lombok을 이용하면 단순히 프로퍼티를 추가하고 삭제하는 것만으로도 충분하다.
Lombok을 이용해서 작성한 코드는 컴파일 과정에서 Annotation을 이용해서 코드를 생성하고 이런 결과물이 .class에 담기게 되는 것이다.
귀찮은 과정을 줄여주고 반복되는 코드 작성을 대신 해준다는 점에서 많은 개발자들이 선호하는 라이브러리이지만 호불호가 갈리는 라이브러리이기도 
하므로 팀 프로젝트에 도입하는 경우 주의해야 한다.

또한 단순히 Annotation을 이용해서 코드를 작성해주는 라이브러리이므로 각 API가 어떤식으로 작동하는지 숙지한 채로 사용하는 것이 좋다. 
다른 라이브러리와 충돌이 발생할 수도 있고 내가 원하지 않는 방식으로 작동할 수도 있기 때문이다.




Annotation?

설명하기 앞서 어노테이션을 보다 쉽게 이해를 돕기위해서 메타데이터란 무엇인지 알아보자 

메타데이터란?
메타데이터란 데이터의 대한 속성정보이다, 데이터에 대한 데이터로서 하위 레벨 데이터를 설명 및 기술하는 데이터라고 보면 된다.
도서관을 예시로 들어보자면 표제,저자,주제명,분류기호 등이 포함되어 있는 목록이 메타데이터의 속한다.

메타데이터를  어느정도 이해하였다, 그렇다면 어노테이션은 무엇인가?
어노테이션이란 메타데이터라고 볼 수 있다.
프로그램 실행 관점에서보면 프로그램이 처리할 메인 데이터가 아니라 실행과정에서 데이터를 어떻게 처리할것인지
알려주는 서브 데이터라고 볼 수 있는 것 이다.

직접적으로 사용해보기 전에 어노테이션의 용도와 사용방식을 알아보자.
어노테이션의 크게 세 가지 용도로 사용된다.
1. 코드 문법 에러 체크 
2. 코드 자동 생성 정보 제공 
3. 런타임시 특정 기능을 실행하는 정보 제공 

어노테이션 사용방식은 크게 두 가지로 나뉜다.
직접 생성하여 사용하는  Custom Annotaion과 JAVA에서 제공하는 Built-in Annotaion 두가지 방식이 있다.
https://simostory.tistory.com/32

JAVA에서 제공하는  어노테이션 Built-in Annotaion 을 알아보자 .
자바에서 기본적으로 제공되는 주요 Built-in Annotaion
 
@Override
메소드가 슈퍼클래스의 메소드를 오버라이드한 메소드라는 정보를 컴파일러에게 전달한다.
 
@Deprecated 
버전업을 하면서 해당 클래스 / 메소드 등이 지원되지 않을 수 있기 때문에 더 이상 사용하지 말라는 경고 메세지를 알려준다. 

@SupressWarning
코드의 대한 오류경고가 발생할시 컴파일러에게 명령을 내려 발생하는 경고를 제거한다.
 
@FunctionalInterface
컴파일러에게 다음의 인터페이스는 함수형 인터페이스라는 것을 알린다, 오바라이딩 어노테이션과 같은 실수방지 용도로 사용된다.
 **/












/**
[참조]
 - Annotaion - 
https://simostory.tistory.com/32
 - Lombok - 
https://mangkyu.tistory.com/78
https://korecm.github.io/Lombok%EC%9D%B4%EB%9E%80
https://projectlombok.org/features/all
https://www.daleseo.com/lombok-useful-annotations/
*/

///*
//어노테이션 없을 경우
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//*/

/*
//전체에 Getter과 Setter이 생성됨
@Getter
@Setter
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//*/

/*
//전체에 Getter이 생성되고, @Setter 선언된 항목만 Setter생선됨
//@Getter
public class CategoryModel extends common {
	@Setter
	@Getter
	private String id;
	@Setter
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//*/

/*
//@AllArgsConstructor는 모든 변수를 사용하는 생성자를 자동완성 시켜주는 어노테이션이다.
@Getter
@AllArgsConstructor
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}

//AllArgsConstructor를 통해 아래의 생성자를 자동 생성할 수 있다. 
//public CategoryModel(String id, String parentId, String name, int depthLevel, int seq, String userYn) {
//	this.id = id;
//	this.parentId = parentId;
//	this.name = name;
//	this.depthLevel = depthLevel;
//	this.seq = seq;
//	this.userYn = userYn;
//}
//*/

/*
//@NoArgsConstructor는 어떠한 변수도 사용하지 않는 기본 생성자를 자동완성 시켜주는 어노테이션이다.
@Getter
@NoArgsConstructor
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}

//NoArgsConstructor를 통해 아래의 생성자를 자동 생성할 수 있다. 
//public CategoryModel() { }
//*/

/*
//@RequiredArgsConstructor는 특정 변수만을 활용하는 생성자를 자동완성 시켜주는 어노테이션이다. 
//생성자의 인자로 추가할 변수에 @NonNull 어노테이션을 붙여서 해당 변수를 생성자의 인자로 추가할 수 있다. 
//아니면 해당 변수를 final로 선언해도 의존성을 주입받을 수 있다.
@Getter
@RequiredArgsConstructor
public class CategoryModel extends common {
	@NotNull
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}

//RequiredArgsConstructor 통해 아래의 생성자를 자동 생성할 수 있다.
//public CategoryModel(String id, String parentId) {
//	this.id = id;
//	this.parentId = parentId;
//}
//*/

/*
//@EqualsAndHashCode 어노테이션을 활용하면 클래스에 대한 equals 함수와 hashCode 함수를 자동으로 생성해준다. 
//만약 서로 다른 두 객체에서 특정 변수의 이름이 똑같은 경우 같은 객체로 판단을 하고 싶다면 아래와 같이 해줄 수 있다.
@RequiredArgsConstructor
@EqualsAndHashCode(of={"id","name"},callSuper=false)
public class CategoryModel extends common {
	@NotNull
	private String id;
	private String parentId;
	@NotNull
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//위의 CategoryModel에서는 @EqualsAndHashCode(of={"id","parentId"}) 로 설정하여 id와 parentId가 동일하다면 같은 객체로 인식하도록 해주고 있다.
//또한 common 객체를 상속하고 있는데, 상위 클래스의 경우 적용시키지 않기 위해 callSuper=false로 해주었다;
//*/

/*
//@ToString 어노테이션을 활용하면 클래스의 변수들을 기반으로 ToString 메소드를 자동으로 완성시켜 준다. 
//출력을 원하지 않는 변수에 @ToString.Exclude 어노테이션을 붙여주면 출력을 제외할 수 있다. 
//또한 상위 클래스에 대해도 toString을 적용시키고자 한다면 상위 클래스에 @ToString(callSuper = true) 를 적용시키면 된다. 
@ToString
@AllArgsConstructor
public class CategoryModel extends common {
//	@ToString.Exclude
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//위의 예제에서는 id변수에 @ToString.Exclude를 붙여주었기 때문에 id를 출력하지 않고 있음을 알 수 있다.
//*/

/*
//@Builder 어노테이션을 활용하면 해당 클래스의 객체의 생성에 Builder패턴을 적용시켜준다. 
//모든 변수들에 대해 build하기를 원한다면 클래스 위에 @Builder를 붙이면 되지만, 
//특정 변수만을 build하기 원한다면 생성자를 작성하고 그 위에 @Builder 어노테이션을 붙여주면 된다.
@Getter
@ToString
@NoArgsConstructor
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
	
	@Builder
	public CategoryModel(String id, String name) {
		this.id = id;
		this.name = name;
	}
}
//*/

/*
//@Delegate 어노테이션은 한 객체의 메소드를 다른 객체로 위임시켜 준다.
@Getter
@ToString
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
	@Delegate
	private List<Company> companyList;
	
	@Builder
	public CategoryModel(String id, String name) {
		this.id = id;
		this.name = name;
		this.companyList = new ArrayList<Company>();
	}
}
//*/

/*
//컬렉션으로 된 필드에는 @Singular 어노테이션을 선언해주면 모든 원소를 한 번에 넘기지 않고 원소를 하나씩 추가할 수 있습니다.
@Getter
@ToString
@Builder
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
	@Singular
	private List<Integer> scores;
//	private List<Company> companys;
}
//*/

/*
@Log
@Getter
@Setter
@RequiredArgsConstructor
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
	
	//@Log 없을 경우에 선언해서 사용해야함.
//	private static final java.util.logging.Logger log = java.util.logging.Logger.getLogger(CategoryModel.class.getName());
	
	public CategoryModel(String id, String name) {
		this.id = id;
		this.name = name;
		log.info("---생성---");
		log.info(this.id);
		log.info(this.name);
	}
}

//*/

/*
@Data
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//*/

/*
@Value
@EqualsAndHashCode(callSuper=false)
public class CategoryModel extends common {
	private String id;
	private String parentId;
	private String name;
	private int depthLevel;
	private int seq;
	private String userYn;
}
//*/


