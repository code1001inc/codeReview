/*
 * @(#)DBManager.java
 */
package com;

import java.sql.*;
import java.util.*;
import javax.sql.*;
import javax.naming.*;

public class DBManager
{
	
	private static long getConnStartTime1 = 0;
	private static long getConnStartTime2 = 0;
	private static long getConnEndTime = 0;
	private static Connection conn = null;
	private static DataSource pool = null;
	
	public static Connection getConn(String str, String src)
	{
		Context ctx = null;
		
		try {
			
//			websphere 연결
//			java.util.Hashtable env = new java.util.Hashtable();
//			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
//			Context ctx = null;
//			ctx = new InitialContext(env);  
//			pool = (DataSource)ctx.lookup(str);
//			////System.out.println("str:"+str);
			
			getConnStartTime1 = System.currentTimeMillis();
			ctx = new InitialContext();
			pool = (DataSource) ctx.lookup("java:comp/env/jdbc/" + str);
			ctx.close();
			
			if (pool == null) {
				////System.out.println("`jdbc/test' is an unknown DataSource");
			}
			conn = pool.getConnection();
			
			
		}
		catch(NamingException e) {
			e.printStackTrace();
		}
		catch(SQLException se) 
		{
			se.printStackTrace();
		}
		getConnStartTime2 = System.currentTimeMillis();
		System.out.println("====="+str+":"+src+";"+(getConnStartTime2-getConnStartTime1)+"=====");
		return conn;
		
		
	}

	public static void close(String str, String src, ResultSet rs, PreparedStatement pstmt, Connection conn) 
	{
		try { if (rs != null) rs.close(); } catch (Exception e) {}
		try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}
	
	public static void close(String str, String src, ResultSet rs, CallableStatement cstmt, Connection conn) 
	{
		try { if (rs != null) rs.close(); } catch (Exception e) {}
		try { if (cstmt != null) cstmt.close(); } catch (Exception e) {}
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}
	
	public static void close(String str, String src, CallableStatement cstmt, Connection conn) 
	{
		try { if (cstmt != null) cstmt.close(); } catch (Exception e) {}
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}


    /**
     * 커넥션의 반환
     * @param pstmt
     * @param conn
     */
	public static void close(String str, String src, PreparedStatement pstmt, Connection conn) 
	{
		try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}

    /**
     * 커넥션의 반환
     * @param stmt
     * @param conn
     */
	public static void close(String str, String src, Statement stmt, Connection conn) 
	{
		try { if (stmt != null) stmt.close(); } catch (Exception e) {}
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}	
	
	public static void close(PreparedStatement pstmt) 
	{
		try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
	}
	
	public static void close(CallableStatement cstmt) 
	{
		try { if (cstmt != null) cstmt.close(); } catch (Exception e) {}
	}
	public static void close(PreparedStatement pstmt , ResultSet rs)
	{
		try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
		try { if (rs != null) rs.close(); } catch (Exception e) {}
	}
	public static void close(ResultSet rs)
	{
		try { if (rs != null) rs.close(); } catch (Exception e) {}
	}
	
	public static void close(String str, String src, Connection conn) 
	{
		try { if (conn != null)	conn.close(); timeCheck(str, src);	} catch (Exception e) {}
	}
	
	public static void timeCheck(String str, String src){
		getConnEndTime = System.currentTimeMillis();
		System.out.println("====="+str+":"+src+";"+(getConnEndTime-getConnStartTime2)+"=====");
	}
	
	
	
	public static void freeConn(String str, String src, Connection conn) {
	    
		try{
			conn.close();
			timeCheck(str, src);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
		
}