package com;

public class common {

}
