package com;

import java.sql.Connection;
import java.util.ArrayList;

import VO.CategoryModel;
import lombok.Cleanup;
import lombok.SneakyThrows;

public class testMain {
	//예외 처리 생략
//	@SneakyThrows
	public static void main(String[] args) {
		
		//자동 자원 닫기
//		@Cleanup Connection conn = DBManager.getConn("", "");
		
		/*
		//@EqualsAndHashCode
		CategoryModel cm1 = new CategoryModel("아이디", "이름");
		CategoryModel cm2 = new CategoryModel("아이디", "이름");
		CategoryModel cm3 = new CategoryModel("아이디", "이름아님");
		
		System.out.println(cm1.equals(cm2));
		System.out.println(cm1.hashCode());
		System.out.println(cm2.hashCode());
		
		System.out.println(cm1.equals(cm3));
		System.out.println(cm3.hashCode());
//		*/
		
		/*
		//@ToString.Exclude
		CategoryModel cm = new CategoryModel("USER1", "PARENT1", "NAME1", 0, 0, "Y");
		System.out.println(cm.toString());
//		*/
		
		/*
		//@Builder
		CategoryModel cm = CategoryModel.builder()
										.id("아이디")
										.name("이름")
										.build();
		System.out.println(cm.toString());
//		*/
		
		/*
		//@Delegate
		Company company = new Company("회사코드", "회사명");
		
		CategoryModel cm = CategoryModel.builder()
										.id("아이디")
										.name("이름")
										.build();
		//기존의 방식
//		cm.getCompanyList().add(company);
		//@Delegate 사용 방식
		cm.add(company);
		
		System.out.println(cm.toString());
//		*/
		
		/*
		//@Singular
		CategoryModel cm = CategoryModel.builder()
										.id("아이디")
										.name("이름")
										.score(80)
										.score(90)
//										.company(new Company("회사코드", "회사명"))
										.build();
		System.out.println(cm.toString());
		
//		*/
		
		/*
		//@Log
		CategoryModel cm = new CategoryModel("아이디", "이름");
//		*/
	}
}