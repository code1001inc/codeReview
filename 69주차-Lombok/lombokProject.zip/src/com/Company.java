package com;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@ToString
@Getter
public class Company extends common {
	private String CompanyCode;
	private String CompanyName;
}
