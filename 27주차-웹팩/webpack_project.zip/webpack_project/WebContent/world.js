// world.js
module.exports = 'world';