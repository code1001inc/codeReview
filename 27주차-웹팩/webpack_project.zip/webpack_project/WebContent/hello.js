// hello.js
module.exports = 'Hello';