const title = document.querySelector("#title");

const CLICKED_COLOR = "clicked";
const UNCLICKED_COLOR = "unclicked";
/*function handleTitleClick(){

	
	if (title.className == CLICKED_COLOR){
		title.className = UNCLICKED_COLOR;
	}else{
		title.className = CLICKED_COLOR;
	}
}*/


function handleTitleClick(){
	/*
	if (title.classList.contains(CLICKED_COLOR)){
		title.classList.remove(CLICKED_COLOR);
		title.classList.add(UNCLICKED_COLOR);	
	}else{
		title.classList.remove(UNCLICKED_COLOR);
		title.classList.add(CLICKED_COLOR);
	}
	*/
	title.classList.toggle(CLICKED_COLOR);
};

title.addEventListener("click", handleTitleClick);
















/*


//const title = document.querySelector("#title");

const CLICKED_COLOR = "clicked";
const UNCLICKED_COLOR = "unclicked";

function handleTitleClick(){
	if (title.className == CLICKED_COLOR){
		title.className = UNCLICKED_COLOR;
	}else{
		title.className = CLICKED_COLOR;
	}
}



function handleTitleClick(){
	if (title.classList.contains(CLICKED_COLOR)){
		title.classList.add(UNCLICKED_COLOR);	
	}else{
		title.classList.add(CLICKED_COLOR);
	}
};


title.addEventListener("click", handleTitleClick);
*/