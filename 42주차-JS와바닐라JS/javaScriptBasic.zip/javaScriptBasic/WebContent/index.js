/* ES2016 문법 제곱근 */
let i = 3 ** 3;
console.log(i);

/* Seleotor */
const title = document.getElementsById("#title");
const titleQuerySeleotor = document.querySelector("#title");       // 모든 자식들 중
																	// 첫번째부터 딱
																	// 하나 찾는다.
const titleQuerySeleotorAll = document.querySelectorAll("#title"); // 모든 자식들 중
																	// 첫번째부터 모두
																	// 찾는다.
const contents = document.getElementsByClassName("contents");
console.log(title);
console.log(contents);
console.log(titleQuerySeleotor);

/* function1 */
function sayHello(name){
	console.log("Hello " + name + " you are 99 years old");
};

function sayHello(name, age){
	console.log("Hello " + name + " you are " + age + " years old");
//	console.log(`Hello ${name} you are ${age} years old`); // `` 백큇(backquit) 사용
};

sayHello("Input Name");
sayHello("Input Name", 30);


/* function2 */
function handleResize(){
	  console.log("oh resized")
};